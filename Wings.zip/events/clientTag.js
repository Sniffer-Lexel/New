const client = require('../index'); // Make sure this correctly points to your bot instance
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");
const { bot } = require('../settings');

const INVITE_URL = `https://discord.com/oauth2/authorize?client_id=1297034029769429023&permissions=8&response_type=code&redirect_uri=https%3A%2F%2Fdiscord.gg%2F7wings&integration_type=0&scope=bot+guilds.join`;
const SUPPORT_SERVER_URL = `https://discord.gg/7wings`;

async function handleMessageCreate(message) {
  if (message.author.bot || !message.guild) return; // Ignore bot messages and DMs

  try {
    const dbPrefix = await client.db8.get(`${message.guild.id}_prefix`);
    const prefix = dbPrefix || bot.info.prefix;

    // Create buttons for invite and support server
    const buttonRow = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel("Invite Me")
        .setStyle("LINK")
        .setURL(INVITE_URL),
      new MessageButton()
        .setLabel("Support Server")
        .setStyle("LINK")
        .setURL(SUPPORT_SERVER_URL)
    );

    // Check if the message mentions the bot
    if (message.content.includes(`<@${client.user.id}>`)) {
      const embed = new MessageEmbed()
        .setColor('#0099ff') // Set a color for the embed
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true })) // Add user avatar
        .setTitle(`Hey <@${message.author.id}>`) // Greet the user with a mention
        .setDescription(`Prefix for this server is \`${prefix}\`\n\nType \`${prefix}help\` for more information.`) // Specify the prefix and help prompt
        .setFooter('Need help? Click a button below!')
        .setTimestamp();

      return message.channel.send({ embeds: [embed], components: [buttonRow] });
    }
  } catch (error) {
    console.error("An error occurred:", error);
    // Send a message to the channel if an error occurs
    if (message.channel) {
      message.channel.send("An error occurred while processing your request. Please try again later.");
    }
  }
}

client.on('messageCreate', handleMessageCreate);
