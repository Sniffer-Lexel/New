const { MessageEmbed } = require("discord.js");
const axios = require("axios");

module.exports = {
  name: "banner",
  run: async (client, message, args) => {
    try {
      // Find user based on mention, username, or use message author
      let user =
        message.mentions.users.first() ||
        message.guild.members.cache.find(
          (member) =>
            member.user.username.toLowerCase() === args.join(" ").toLowerCase()
        )?.user || // Access the User object if found
        message.author;

      // Fetch user data from Discord API
      const { data } = await axios.get(
        `https://discord.com/api/users/${user.id}`,
        {
          headers: {
            Authorization: `Bot ${client.token}`,
          },
        }
      );

      // Check if the user has a banner
      if (data.banner) {
        const bannerUrl = `https://cdn.discordapp.com/banners/${user.id}/${data.banner}.png?size=4096`;

        const embed = new MessageEmbed()
          .setColor(client.color || "#5865F2") // Default to Discord blurple if client.color is undefined
          //.setTitle(`Banner of ${user.username}`)
          .setImage(bannerUrl)
          .setFooter(`Requested by: ${message.author.username}`, message.author.displayAvatarURL({ dynamic: true }));

        message.channel.send({ embeds: [embed] });
      } else {
        const embed = new MessageEmbed()
          .setColor(client.color || "#5865F2")
          .setDescription(`${user.username} doesn't have a banner.`);

        message.channel.send({ embeds: [embed] });
      }
    } catch (error) {
      console.error("Error fetching banner:", error);
      const errorEmbed = new MessageEmbed()
        .setColor("#ff0000")
        .setDescription("An error occurred while fetching the banner. Make sure the bot has the necessary permissions and try again.");

      message.channel.send({ embeds: [errorEmbed] });
    }
  },
};
