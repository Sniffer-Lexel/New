const { MessageEmbed } = require('discord.js');
const { MfaAccess } = require('../../owner.json'); // Assuming MfaAccess contains an array of owner IDs

async function addUserToAccessList(client, ID) {
    const data = await client.db4.get(`movefast_access`);
    if (!data) {
        await client.db4.set(`movefast_access`, { accessList: [ID] });
        return 'added';
    } else {
        if (data.accessList.includes(ID)) {
            return 'already_added';
        } else {
            await client.db4.push(`movefast_access.accessList`, ID);
            return 'added';
        }
    }
}

async function removeUserFromAccessList(client, ID) {
    const data = await client.db4.get(`movefast_access`);
    if (!data) {
        return 'not_found';
    } else {
        if (!data.accessList.includes(ID)) {
            return 'not_found';
        } else {
            await client.db4.pull(`movefast_access.accessList`, ID);
            return 'removed';
        }
    }
}

async function getAccessList(client) {
    const data = await client.db4.get(`movefast_access`);
    return data ? data.accessList : [];
}

module.exports = {
    name: 'manageAccess',
    aliases: ['ma'],
    run: async (client, message, args) => {
        // Check if the user is in the MfaAccess array
        if (!MfaAccess.includes(message.author.id)) {
            const noPermissionEmbed = new MessageEmbed()
                .setColor('#2f3136')
                .setDescription('You do not have permission to use this command.');
            return message.channel.send({ embeds: [noPermissionEmbed] });
        }

        const subcommand = args[0];
        const targetUser = message.mentions.members.first() || message.guild.members.cache.get(args[1]);

        if (!subcommand) {
            const invalidCommandEmbed = new MessageEmbed()
                .setColor('#2f3136')
                .setDescription('Please provide a valid subcommand: add/remove/show.');
            return message.channel.send({ embeds: [invalidCommandEmbed] });
        }

        switch (subcommand) {
            case 'add': {
                if (!targetUser) {
                    const mentionUserEmbed = new MessageEmbed()
                        .setColor('#2f3136')
                        .setDescription('<a:Cross:1300389161462661131> |  Please mention a user to grant access.');
                    return message.channel.send({ embeds: [mentionUserEmbed] });
                }
                const result = await addUserToAccessList(client, targetUser.id);
                const addedEmbed = new MessageEmbed()
                    .setColor('#2f3136')
                    .setDescription(result === 'already_added' 
                        ? `<a:Check:1300389146925334578> |  User ${targetUser.user.username} already has access.` 
                        : `<a:Check:1300389146925334578> |  Granted access to ${targetUser.user.username}.`
                    )
                return message.channel.send({ embeds: [addedEmbed] });
            }
            case 'remove': {
                if (!targetUser) {
                    const mentionUserEmbed = new MessageEmbed()
                        .setColor('#2f3136')
                        .setDescription('<a:Cross:1300389161462661131> |  Please mention a user to revoke access');
                    return message.channel.send({ embeds: [mentionUserEmbed] });
                };
                const result = await removeUserFromAccessList(client, targetUser.id);
                const removedEmbed = new MessageEmbed()
                    .setColor('#2f3136')
                    .setDescription(result === 'not_found' 
                        ? `<a:Cross:1300389161462661131> |  User ${targetUser.user.username} does not have access.` 
                        : `<a:Check:1300389146925334578> |  Revoked access from ${targetUser.user.username}.`
                    );
                return message.channel.send({ embeds: [removedEmbed] });
            }
            case 'list': {
                const accessList = await getAccessList(client);
                const accessEmbed = new MessageEmbed()
                    .setColor('#2f3136')
                    .setTitle('<:Category:1300389238013165578> |  Users with Access')
                    .setDescription(accessList.length === 0 
                        ? 'No users have access.' 
                        : accessList.map(id => `<@${id}>`).join(', ')
                    );
                return message.channel.send({ embeds: [accessEmbed] });
            }
            default: {
                const invalidCommandEmbed = new MessageEmbed()
                    .setColor('#2f3136')
                    .setDescription('Invalid subcommand. Use add/remove/show.');
                return message.channel.send({ embeds: [invalidCommandEmbed] });
            }
        }
    }
};
