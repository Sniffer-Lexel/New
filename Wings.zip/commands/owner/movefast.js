const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'movefast',
    aliases: ['mf'],
    category: 'voice',
    run: async (client, message, args) => {
        const accessList = await client.db4.get(`movefast_access.accessList`);
        const userHasAccess = accessList && accessList.includes(message.author.id);

        if (!userHasAccess) {
            const error = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`You do not have permission to use this command.`);
            return message.channel.send({ embeds: [error] });
        }

        // Check if the user has permission to move members
        if (!message.member.permissions.has('MOVE_MEMBERS')) {
            const error = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`You must have \`Move members\` permission to use this command.`);
            return message.channel.send({ embeds: [error] });
        }

        // Check if the bot has permission to move members
        if (!message.guild.me.permissions.has('MOVE_MEMBERS')) {
            const error = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`I must have \`Move members\` permission to use this command.`);
            return message.channel.send({ embeds: [error] });
        }

        // Get the user to move
        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

        if (!user || !user.voice.channel) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`Please mention a user who is in a voice channel.`)
                ]
            });
        }

        // Get all voice channels in the guild
        const voiceChannels = message.guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE');

        if (voiceChannels.size < 2) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`There aren't enough voice channels to move the user.`)
                ]
            });
        }

        // Function to move the user to a random voice channel
        const moveUserRandomly = async () => {
            let randomChannel;
            do {
                randomChannel = voiceChannels.random();
            } while (randomChannel.id === user.voice.channel.id);

            await user.voice.setChannel(randomChannel);
            const sentMessage = await message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`Moved ${user} to ${randomChannel.name}.`)
                ]
            });

            setTimeout(() => sentMessage.delete(), 2000);
        };

        const interval = setInterval(async () => {
            if (!user.voice.channel) {
                clearInterval(interval);
                const stopMessage = await message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription(`User left the voice channel. Stopping movement.`)
                    ]
                });
                setTimeout(() => stopMessage.delete(), 2000);
            } else {
                await moveUserRandomly();
            }
        }, 1000);

        setTimeout(() => clearInterval(interval), 60000);
    }
};
