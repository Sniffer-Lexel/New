const {
  MessageActionRow,
  MessageEmbed,
  MessageSelectMenu,
} = require("discord.js");
const Settings = require("../../settings.js");
const emoji = require("../../emoji.js");
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: "help",
  aliases: ["h"],
  run: async function (client, message, args) {
    const prefix =
      (await client.db8.get(`${message.guild.id}_prefix`)) ||
      Settings.bot.info.prefix;
    
    // Create the main menu options
    const menuOptions = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId("helpOption")
        .setPlaceholder("Choose A Module")
        .addOptions([
          {
            label: "Home",
            value: "h1",
            emoji: "1156273221201567814",
            description: "See Home Page",
          },
          {
            label: "Antinuke",
            value: "h2",
            emoji: "1300389179745894452",
            description: "See the Antinuke Commands",
          },
          {
            label: "Automod",
            value: "h3",
            emoji: "1300392619582427147",
            description: "See the Automod Commands",
          },
          {
            label: "Moderation",
            value: "h4",
            emoji: "1300672892933111920",
            description: "See the Moderation Commands",
          },
          {
            label: "Welcome",
            value: "h5",
            emoji: "1300392424438501417",
            description: "See the Welcome Commands",
          },
          {
            label: "Server",
            value: "h6",
            emoji: "1300389238013165578",
            description: "See the Server Commands",
          },
          {
            label: "Voice Role",
            value: "h7",
            emoji: "1300389131133779978",
            description: "See the Voice Role Commands",
          },
          {
            label: "Custom Roles",
            value: "h8",
            emoji: "1300393376788774985",
            description: "See the Custom Roles Commands",
          },
          {
            label: "Media",
            value: "h9",
            emoji: "1300671432597966879",
            description: "See the Media Commands",
          },
          {
            label: "Games",
            value: "h10",
            emoji: "1300672198054514698",
            description: "See the Games Commands",
          },
          {
            label: "Utility",
            value: "h11",
            emoji: "1300389117678325813",
            description: "See the Utility Commands",
          },
        ])
    );

    // Main Help Embed
    const embed1 = new MessageEmbed()
      .setColor('#97a199')
      .setAuthor({
        name: `${message.guild.name}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `Hey! Wings - Your Powerful Anti-Nuke & Moderation Bot! 
        - **[Support](https://discord.gg/7wings)**
        - **[Invite Me](https://discord.com/oauth2/authorize?client_id=1297034029769429023&permissions=8&response_type=code&redirect_uri=https%3A%2F%2Fdiscord.gg%2F7wings&integration_type=0&scope=bot+guilds.join)**`
      )
      .addFields({
        name: "__Commands__",
        value: `${emoji.id.antinuke} - Antinuke\n${emoji.id.automod} - Automod\n${emoji.id.moderation} - Moderation\n${emoji.id.welcome} - Welcome\n${emoji.id.ignore} - Server\n${emoji.id.voiceroles} - VoiceRoles\n${emoji.id.customroles} - Custom Role\n${emoji.id.media} - Media\n${emoji.id.games} - Games\n${emoji.id.utility} - Utility\n\nChoose a category below.`,
      });

    // Each module embed
    const embeds = {
      h2: new MessageEmbed()
      .setColor(client.color)
      .addFields({
        name: `${emoji.id.antinuke} Antinuke Commands`,
        value: "`antinuke`, `antinuke guide`, `antinuke features`, `antinuke enable/disable`, `antinuke <event create/delete/update> enable/disable`, `antinuke whitelist add/remove <user mention/id>`, `antinuke whitelist reset`, `antinuke config`, `antinuke reset`, `nightmode`, `nightmode enable/disable`, `nightmode role add/remove <role mention/id>`, `nightmode bypass add/remove <user mention/id>`, `nightmode role/bypass show`, `nightmode role/bypass reset`",
       }),
      h3: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.automod} Automod Commands`,
          value: "`antilink`, `antilink enable`, `antilink disable`, `antieveryone`, `antieveryone enable`, `antieveryone disable`, `automod anti pornography enable/disable`, `automod anti message spam enable/disable`, `automod anti mention spam enable/disable`, `automod anti toxicity enable/disable`, `automod config`, `automod reset`",
        }),
      h4: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.moderation} Moderation Commands`,
          value: "`clear bots`, `clear humans`, `clear embeds`, `clear files`, `clear mentions`, `clear pins`, `ban <user>`, `unban <user>`, `kick <user>`, `hide <channel>`, `unhide <channel>`, `lock <channel>`, `unlock <channel>`, `nuke`, `purge`, `voice`, `voice muteall`, `voice unmuteall`, `voice deafenall`, `voice undeafenall`, `voice mute <user>`, `voice unmute <user>`, `voice deafen <user>`, `voice undeafen <user>`",
        }),
      h5: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.welcome} Welcome Commands`,
          value: "`welcome`, `welcome message panel`, `welcome test`, `welcome reset`, `autorole`, `autorole humans add <role mention/id>`, `autorole humans remove <role mention/id>`, `autorole bots add <role mention/id>`, `autorole bots remove <role mention/id>`, `autorole config`, `autorole reset`",
        }),
      h6: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.ignore} Server Commands`,
          value: "`extra`, `extra owner add <user mention/id>`, `extra admin add <user mention/id>`, `extra owner remove <user mention/id>`, `extra admin remove <user mention/id>`, `extra owner show`, `extra admin show`, `extra owner reset`, `extra admin reset`, `ignore`, `ignore channel add <channel mention/id>`, `ignore bypass add <channel mention/id>`, `ignore channel remove <channel mention/id>`, `ignore bypass remove <channel mention/id>`, `ignore channel show`, `ignore bypass show`, `ignore channel reset`, `ignore bypass reset`",
        }),
      h7: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.voiceroles} Voice Roles Commands`,
          value: "`invc`, `invc humans <role>`, `invc bots <role>`, `invc config`, `invc reset`",
        }),
      h8: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.customroles} Custom Role Commands`,
          value: "`setup`, `setup config`, `setup reqrole <role mention/id>`, `setup admin <role mention/id>`, `setup official <role mention/id>`, `setup private <role mention/id>`, `setup reset`",
        }),
      h9: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.media} Media Commands`,
          value: "`media`, `media add`, `media remove`, `media list`, `media enable/disable`",
        }),
      h10: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.games} Games Commands`,
          value: "`games`, `games add`, `games remove`, `games list`, `games enable/disable`",
        }),
      h11: new MessageEmbed()
        .setColor(client.color)
        .addFields({
          name: `${emoji.id.utility} Utility Commands`,
          value: "`utility`, `utility add`, `utility remove`, `utility list`, `utility enable/disable`",
        }),
    };

    // Send the initial reply and store the message
    const helpMessage = await message.reply({ embeds: [embed1], components: [menuOptions] });

    const collector = message.channel.createMessageComponentCollector({
      filter: (i) => i.user.id === message.author.id,
    });

    // Timeout to disable the components after 2 minutes
    setTimeout(async () => {
      await helpMessage.edit({ components: [] }); // Disable the menu
      await helpMessage.followUp({ content: "The help menu has ended.", ephemeral: true });
    }, 60000); // 120000 ms = 2 minutes

    collector.on("collect", async (interaction) => {
      if (!interaction.isSelectMenu()) return;

      const value = interaction.values[0];

      if (value === "h1") {
        await interaction.update({ embeds: [embed1], components: [menuOptions] });
      } else if (embeds[value]) {
        await interaction.update({
          embeds: [embeds[value]],
          components: [menuOptions], // keep the menu enabled
        });
      } else {
        await interaction.update({
          content: "An error occurred!",
          ephemeral: true,
        });
      }
    });
  },
};
