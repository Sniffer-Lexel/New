const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const emoji = require('../../emoji.js');
const Settings = require('../../settings.js');
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: 'voice',
  voteOnly: true,
  UserPerms: ['MUTE_MEMBERS', 'DEAFEN_MEMBERS'],
  BotPerms: ['DEAFEN_MEMBERS', 'MUTE_MEMBERS', 'EMBED_LINKS'],
  aliases: ["vc"],
  run: async (client, message, args) => {
    let prefix = await client.db8.get(`${message.guild.id}_prefix`);
    if (!prefix) prefix = Settings.bot.info.prefix;
    const arypton = await client.users.fetch(owner);
    const option = args[0];
    const channel = message.guild.channels.cache.get(args[0]) || message.member.voice.channel;
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    const mentionChannelEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(client.user.tag, client.user.displayAvatarURL())
      .setDescription(`Please mention a valid voice channel first.`);

    const mentionMemberEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(client.user.tag, client.user.displayAvatarURL())
      .setDescription(`Please mention a member first.`);

    const guideEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(client.user.tag, client.user.displayAvatarURL())
      .addField(`${emoji.util.arrow} \`voice muteall\``, "Mute all members in a voice channel")
      .addField(`${emoji.util.arrow} \`voice unmuteall\``, "Unmute all members in a voice channel")
      .addField(`${emoji.util.arrow} \`voice deafenall\``, "Deafen all members in a voice channel")
      .addField(`${emoji.util.arrow} \`voice undeafenall\``, "Undeafen all members in a voice channel")
      .addField(`${emoji.util.arrow} \`voice mute <user>\``, "Mute a member in a voice channel")
      .addField(`${emoji.util.arrow} \`voice unmute <user>\``, "Unmute a member in a voice channel")
      .addField(`${emoji.util.arrow} \`voice deafen <user>\``, "Deafen a member in a voice channel")
      .addField(`${emoji.util.arrow} \`voice undeafen <user>\``, "Undeafen a member in a voice channel")
      .setFooter({ text: `Requested By: ${message.author.username}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    const buttonRow = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel("Vote Me")
        .setStyle("LINK")
        .setURL(`https://top.gg/bot/1002306671261003948?s=0ae05abf3185d`),
      new MessageButton()
        .setLabel("Invite Me")
        .setStyle("LINK")
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=1002306671261003948&permissions=8&scope=bot%20applications.commands`)
    );

    // If no option is provided, show the guide
    if (!option) {
      return message.channel.send({ embeds: [guideEmbed], components: [buttonRow] });
    }

    // Function to mute all members in a voice channel
    async function muteAllMembers(channel) {
      const mentionedUsers = [];
      for (const [_, member] of channel.members) {
        await member.voice.setMute(true);
        mentionedUsers.push(member);
      }
      const muteEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`\`${channel.name}\` ${emoji.util.tick} All members in your channel have been muted.`)
        .addField("Muted Members:", mentionedUsers.map(user => user.toString()).join(", ") || "No members were found.");
      message.channel.send({ embeds: [muteEmbed] });
    }

    // Function to unmute all members in a voice channel
    async function unmuteAllMembers(channel) {
      const mentionedUsers = [];
      for (const [_, member] of channel.members) {
        await member.voice.setMute(false);
        mentionedUsers.push(member);
      }
      const unmuteEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`\`${channel.name}\` ${emoji.util.tick} All members in your channel have been unmuted.`)
        .addField("Unmuted Members:", mentionedUsers.map(user => user.toString()).join(", ") || "No members were found.");
      message.channel.send({ embeds: [unmuteEmbed] });
    }

    // Function to deafen all members in a voice channel
    async function deafenAllMembers(channel) {
      const mentionedUsers = [];
      for (const [_, member] of channel.members) {
        await member.voice.setDeaf(true);
        mentionedUsers.push(member);
      }
      const deafenEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`\`${channel.name}\` ${emoji.util.tick} All members in your channel have been deafened.`)
        .addField("Deafened Members:", mentionedUsers.map(user => user.toString()).join(", ") || "No members were found.");
      message.channel.send({ embeds: [deafenEmbed] });
    }

    // Function to undeafen all members in a voice channel
    async function undeafenAllMembers(channel) {
      const mentionedUsers = [];
      for (const [_, member] of channel.members) {
        await member.voice.setDeaf(false);
        mentionedUsers.push(member);
      }
      const undeafenEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`\`${channel.name}\` ${emoji.util.tick} All members in your channel have been undeafened.`)
        .addField("Undeafened Members:", mentionedUsers.map(user => user.toString()).join(", ") || "No members were found.");
      message.channel.send({ embeds: [undeafenEmbed] });
    }

    // Function to mute a specific member
    async function muteMember(member) {
      await member.voice.setMute(true);
      const muteEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`${emoji.util.tick} | Member Muted: ${member}`);
      message.channel.send({ embeds: [muteEmbed] });
    }

    // Function to unmute a specific member
    async function unmuteMember(member) {
      await member.voice.setMute(false);
      const unmuteEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`${emoji.util.tick} | Member Unmuted: ${member}`);
      message.channel.send({ embeds: [unmuteEmbed] });
    }

    // Function to deafen a specific member
    async function deafenMember(member) {
      await member.voice.setDeaf(true);
      const deafenEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`${emoji.util.tick} | Member Deafened: ${member}`);
      message.channel.send({ embeds: [deafenEmbed] });
    }

    // Function to undeafen a specific member
    async function undeafenMember(member) {
      await member.voice.setDeaf(false);
      const undeafenEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`${emoji.util.tick} | Member Undeafened: ${member}`);
      message.channel.send({ embeds: [undeafenEmbed] });
    }

    switch (option.toLowerCase()) {
      case 'muteall':
        if (!channel || channel.type !== 'GUILD_VOICE') {
          return message.channel.send({ embeds: [mentionChannelEmbed] });
        }
        await muteAllMembers(channel);
        break;

      case 'unmuteall':
        if (!channel || channel.type !== 'GUILD_VOICE') {
          return message.channel.send({ embeds: [mentionChannelEmbed] });
        }
        await unmuteAllMembers(channel);
        break;

      case 'deafenall':
        if (!channel || channel.type !== 'GUILD_VOICE') {
          return message.channel.send({ embeds: [mentionChannelEmbed] });
        }
        await deafenAllMembers(channel);
        break;

      case 'undeafenall':
        if (!channel || channel.type !== 'GUILD_VOICE') {
          return message.channel.send({ embeds: [mentionChannelEmbed] });
        }
        await undeafenAllMembers(channel);
        break;

      case 'mute':
        if (!member) {
          return message.channel.send({ embeds: [mentionMemberEmbed] });
        }
        await muteMember(member);
        break;

      case 'unmute':
        if (!member) {
          return message.channel.send({ embeds: [mentionMemberEmbed] });
        }
        await unmuteMember(member);
        break;

      case 'deafen':
        if (!member) {
          return message.channel.send({ embeds: [mentionMemberEmbed] });
        }
        await deafenMember(member);
        break;

      case 'undeafen':
        if (!member) {
          return message.channel.send({ embeds: [mentionMemberEmbed] });
        }
        await undeafenMember(member);
        break;

      default:
        return message.channel.send({ embeds: [guideEmbed], components: [buttonRow] });
    }
  }
};
