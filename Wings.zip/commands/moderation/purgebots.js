const { MessageEmbed } = require('discord.js');
const emoji = require('../../emoji.js');

async function bulkDeleteBotMessages(message, amount, client) {
    const fetchedMessages = await message.channel.messages.fetch({ limit: amount + 1 });
    const botMessages = fetchedMessages.filter(msg => msg.author.bot);

    if (botMessages.size === 0) {
        return message.reply({
            embeds: [
                new MessageEmbed()
                    .setColor(client.color)
                    .setDescription(`${emoji.util.cross} |  There were no bot messages to purge.`)
            ]
        });
    }

    // Delete the bot messages
    const deletedMessages = await message.channel.bulkDelete(botMessages, true).catch(err => {
        console.error("Error deleting messages:", err);
        return [];
    });

    message.channel.send({
        embeds: [
            new MessageEmbed()
                .setColor(client.color)
                .setDescription(`${emoji.util.tick} |  Successfully deleted ${deletedMessages.length} bot messages.`)
        ]
    }).then(m => {
        setTimeout(() => {
            m.delete().catch(() => {});
        }, 3000);
    });
}

module.exports = {
    name: 'purgebots',
    aliases: ['pb'],
    category: 'mod',
    premium: true,
    UserPerms: ['MANAGE_MESSAGES'],
    BotPerms: ['MANAGE_MESSAGES', 'READ_MESSAGE_HISTORY', 'EMBED_LINKS'],
    run: async (client, message, args) => {
        // Check if user has the required permissions
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`${emoji.util.cross} |  You must have \`Manage Messages\` permissions to use this command.`)
                ]
            });
        }

        // Check if the bot has the required permissions
        if (!message.guild.members.me.permissions.has(['MANAGE_MESSAGES', 'READ_MESSAGE_HISTORY'])) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`${emoji.util.cross} |  I must have \`Manage Messages\`, \`Read Message History\` permissions to use this command.`)
                ]
            });
        }

        // Parse the amount
        const amount = parseInt(args[0]) || 99;

        // Validate the amount
        if (isNaN(amount) || amount <= 0 || amount > 99) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`${emoji.util.cross} |  Please provide a valid number of bot messages to delete (1-99).`)
                ]
            });
        }

        // Call the bulk delete function
        await bulkDeleteBotMessages(message, amount, client);
    }
};
