const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'ban',
  aliases: ['hackban', 'fuckban', 'fuckyou', 'fuckoff'],
  category: 'moderation',
  UserPerms: ['BAN_MEMBERS'],
  BotPerms: ['BAN_MEMBERS'],
  aboveRole: true,
  usage: 'ban <user mention/id> <reason>',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    // Check for arguments
    if (!args[0]) {
      const errorEmbed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Somebody is breaking rules again and again | ban him from the server as punishment`)
        .addField('Aliases', '`hackban` | `fuckban` | `fuckyou` | `fuckoff`')
        .addField('Usage', `\`${prefix}ban <member> [reason=None]\``);
      return message.channel.send({ embeds: [errorEmbed] });
    }

    // Fetch user
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.channel.send(`${emoji.util.cross} | Please provide a valid user mention or ID.`);
    }

    // Get the target member from the guild
    const targetMember = message.guild.members.cache.get(user.id);
    if (!targetMember) {
      return message.channel.send(`${emoji.util.cross} | The provided user is not a member of this server.`);
    }

    // Self-ban prevention
    if (targetMember.id === message.author.id) {
      return message.channel.send(`${emoji.util.cross} | You cannot ban yourself.`);
    }

    // Bot ban prevention
    if (targetMember.id === client.user.id) {
      return message.channel.send(`${emoji.util.cross} | You can't ban the bot itself.`);
    }

    // Permission checks
    if (!targetMember.bannable || targetMember.roles.highest.comparePositionTo(message.guild.me.roles.highest) > 0) {
      return message.channel.send(`${emoji.util.cross} | I cannot ban this user. They may have a higher role than me or I do not have sufficient permissions.`);
    }

    // Get the reason
    args.shift(); // Remove the first argument (user mention/ID)
    const reason = args.join(' ') || 'Not provided.';

    // Attempt to ban the user
    try {
      await targetMember.ban({ reason });
      await message.channel.send(`${emoji.util.tick} | Successfully banned \`${user.username}\` | Reason: ${reason}`);

      // Attempt to DM the user
      try {
        await targetMember.send(`You have been banned from **${message.guild.name}** by \`${message.author.username}\`. | Reason: ${reason}`);
      } catch (dmError) {
        console.warn(`Failed to send DM to ${user.tag}: ${dmError.message}`);
        // Notify the channel about the DM failure
        await message.channel.send(`${emoji.util.info} | Unable to send a DM to the user about their ban.`);
      }
    } catch (error) {
      console.error(`Failed to ban ${user.tag}: ${error.message}`);
      return message.channel.send(`${emoji.util.cross} | An error occurred while trying to ban the user. Please try again.`);
    }
  }
};
