const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "ping",
  description: "Shows the bot's latency and other relevant information.",
  run: async (client, message, args) => {
    const start = Date.now();

    // Calculate database latency
    let dbLatency = "N/A"; // Default to N/A if database query fails
    try {
      const startTime = Date.now();
      await client.db4.get("members_np"); // Replace with your actual database query
      dbLatency = Date.now() - startTime;
    } catch (error) {
      console.error("Error fetching database latency:", error);
    }

    // Calculate latencies
    const apiLatency = client.ws.ping;
    const messageLatency = Date.now() - message.createdTimestamp;

    // Create an embed with latency information
    const embed = new MessageEmbed()
      .setColor("#2f3136")
      .setTitle("Heaven Latency")
      .setDescription("Here's the current latency:")
      .addFields(
        { name: "API Latency:", value: `${apiLatency.toFixed(0)} ms`, inline: true },
        { name: "Message Latency:", value: `${messageLatency.toFixed(0)} ms`, inline: true },
        { name: "Database Latency:", value: `${dbLatency.toFixed(0)} ms`, inline: true },
        { name: "Node Latency:", value: `${(Date.now() - start).toFixed(0)} ms`, inline: true }
      )
      .setThumbnail(client.user.displayAvatarURL())
      .setTimestamp();

    return message.channel.send({ embeds: [embed] });
  },
};