const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");

function createInviteEmbed(client) {
  const embed = new MessageEmbed()
    .setColor(client.color)
    .setAuthor(client.user.tag, client.user.displayAvatarURL())
    .setDescription("Click the button below.");

  return embed;
}

function createInviteButton(client) {
  const button = new MessageActionRow().addComponents(
    new MessageButton()
      .setLabel("Invite Me")
      .setStyle("LINK")
      .setURL(`https://discord.com/oauth2/authorize?client_id=1289242734527254652&permissions=8&integration_type=0&scope=bot`)
  );

  return button;
}

module.exports = {
  name: "invite",
  run: async (client, message, args) => {
    const embed = createInviteEmbed(client);
    const button = createInviteButton(client);

    message.reply({ embeds: [embed], components: [button] });
  },
};
