const { MessageEmbed } = require("discord.js");
const Settings = require('../../settings.js');
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: "avatar",
  aliases: ["av", "pfp", "pic"],
  usage: "[user mention]",
  run: async function (client, message, args) {
    // If a user is mentioned, use their avatar; otherwise, use the author's avatar
    const user = message.mentions.users.first() || message.author;

    // Create the avatar embed with text links
    const avatarEmbed = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(user.username, user.displayAvatarURL())
      .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
      .setDescription(
        `[\`PNG\`](${user.displayAvatarURL({ format: "png", size: 2048 })}) | ` +
        `[\`JPG\`](${user.displayAvatarURL({ format: "jpg", size: 2048 })}) | ` +
        `[\`WEBP\`](${user.displayAvatarURL({ format: "webp", size: 2048 })})`
      )
      .setFooter(`Requested By ${message.author.username}`, message.author.displayAvatarURL({ dynamic: true }));

    // Send the embed
    message.channel.send({ embeds: [avatarEmbed] });
  }
};
